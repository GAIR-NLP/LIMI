---
tags:
- text-generation
- agent
- tool-use
- long-context
license: other
language:
- en
pipeline_tag: text-generation
---

# LIMI‑Air: Less is More for Agency 🚀

## 📌 Table of Contents
- [Overview](#overview)
- [Model Details](#model-details)
- [Dataset](#dataset)
- [Quick Start](#quick-start)
- [Prompting](#prompting)
- [Evaluation](#evaluation)
- [Limitations](#limitations)
- [License](#license)
- [Citation](#citation)

## Overview

LIMI‑Air is a smaller, faster agentic variant built on GLM‑4.5‑Air (~106B), fine‑tuned with the same compact, high‑quality agentic data as LIMI.

## Model Details

- Base model: `zai-org/GLM-4.5-Air`
- Params: ~106B
- Context: up to 128k tokens (training budget)
- Framework: slime; Data: [GAIR/limi](https://huggingface.co/datasets/GAIR/limi)
## Key Results
 
| Model | Agency Bench FTFC | Agency Bench SR | Agency Bench RC | Training Samples |
|-------|--------|---------|---------|-----------------|
| LIMI (Ours) | **71.7** | **74.2** |**74.6**| 78 |
| GLM-4.5 | 37.8 | 50.0 | 47.4 | 100k+ |
## Model Zoo

Our LIMO model is available on Hugging Face 🤗:

| Model | Backbone | Size | Link |
|---|---|---|---|
| LIMI | [GLM‑4.5](https://huggingface.co/zai-org/GLM-4.5) | 355B | https://huggingface.co/GAIR/LIMI |
| LIMI‑Air | [GLM‑4.5‑Air](https://huggingface.co/zai-org/GLM-4.5-Air) | 106B | https://huggingface.co/GAIR/LIMI-Air |


## Datasets

We release our datasets through Hugging Face 🤗:
- Name: `GAIR/limi`
- Summary: curated agentic SFT data (OpenAI `messages`, optional `tools`, normalized tool‑call arguments), filtered by tokenizer to ≤128k tokens; current release contains ~78 high‑quality samples.
- Link: https://huggingface.co/datasets/GAIR/limi

## Quick Start

<details>
<summary>Start with HF Transformers</summary>

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model = AutoModelForCausalLM.from_pretrained(
    "GAIR/LIMI-Air", torch_dtype="auto", device_map="auto", trust_remote_code=True
)
tok = AutoTokenizer.from_pretrained("GAIR/LIMI-Air", trust_remote_code=True)
text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
out = model.generate(
    **tok(text, return_tensors="pt").to(model.device),
    max_new_tokens=4096,
    temperature=0.6,
    top_p=0.95,
    do_sample=True,
)
```

</details>

<details>
<summary>Start with VLLM</summary>

```python
from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

llm = LLM(model="GAIR/LIMI-Air", trust_remote_code=True)
tok = AutoTokenizer.from_pretrained("GAIR/LIMI-Air", trust_remote_code=True)
text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
out = llm.generate(text, SamplingParams(temperature=0.6, max_tokens=4096, top_p=0.95))
```

</details>

## Prompting

Same as LIMI; provide messages in OpenAI chat format, optionally with `tools`. Include a grounding system message when helpful.

## Evaluation

Uses the same metrics (FTFC, SR@R, RC@R at R=3) and protocol as LIMI; see the paper for comparative results.

## Limitations

- Inherits base model constraints; validated on curated agentic tasks only
- Lower compute cost with potential performance trade‑offs on complex tasks

## License

- Inherits GLM‑4.5‑Air terms; verify upstream license before deployment

## Citation

```bibtex
@article{LIMI2025,
  title   = {Less is More for Agentic Intelligence},
  author  = {LIMI Authors},
  year    = {2025},
  journal = {arXiv preprint arXiv:2502.03387}
}
```
