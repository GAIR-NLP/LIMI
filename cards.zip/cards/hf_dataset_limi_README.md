---
tags:
- datasets
- sft
- chat
- tool-use
license: other
language:
- en
task_categories:
- text-generation
pretty_name: LIMI (Agentic SFT)
---

# LIMI: Less is More for Agency

## 📌 Table of Contents
- [Dataset Summary](#dataset-summary)
- [Data Fields](#data-fields)
- [Splits](#splits)
- [Examples](#examples)
- [Usage](#usage)
- [Preparation Notes](#preparation-notes)
- [License](#license)
- [Citation](#citation)

## Dataset Summary

Curated agentic training data with OpenAI‑style multi‑turn dialogs and tool calls. Focuses on functional completeness, correction over rounds, and spec adherence. Long‑context samples are filtered to ≤128k tokens using the target tokenizer.

## Data Fields

- `messages` (list): chat messages with roles `system` | `user` | `assistant` | `tool`
- `tools` (optional list): OpenAI function‑call schemas
- `assistant.tool_calls` (optional, list): entries like `{ "type": "function", "function": { "name": str, "arguments": object } }`

## Splits

- `train`: 78 samples (current release)

## Examples

```json
{
  "messages": [
    {"role": "system", "content": "You are a helpful assistant tasked with discovering mathematical function structures for scientific systems."},
    {"role": "user", "content": "Modify the equation.py function, considering the physical meaning and relationships of the inputs."}
  ],
  "tools": [
    {"type": "function", "function": {"name": "run_tests", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}}
  ]
}
```
## License

- Provided for research; verify final license policy before redistribution

## Citation

```bibtex
@article{LIMI2025,
  title   = {Less is More for Agentic Intelligence},
  author  = {LIMI Authors},
  year    = {2025},
  journal = {arXiv preprint arXiv:2502.03387}
}
```
